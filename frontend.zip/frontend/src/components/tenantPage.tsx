import React from "react";
import OTPVerificationForm from "./user-verification-form";

const TenantPage = () => {
  return (
    <div>
      <OTPVerificationForm />
    </div>
  );
};

export default TenantPage;
